#!/system/bin/sh
ui_print "[*] Ultimate Booster (KernelSU) Installing..."
ui_print "[*] Thermal Killer + Touch Boost Ready!"