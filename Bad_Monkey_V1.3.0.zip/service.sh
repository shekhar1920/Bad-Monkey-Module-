#!/system/bin/sh
# Ultimate Free Fire Booster - KernelSU Module
# service.sh

MODDIR=${0%/*}

apply_tweaks() {
    # CPU lock (all cores online)
    for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
        echo 1 > $cpu/online 2>/dev/null
    done

    # CPU governor performance
    echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null

    # GPU lock
    echo 1100000000 > /sys/class/devfreq/13000000.mali/min_freq
    echo 1100000000 > /sys/class/devfreq/13000000.mali/max_freq
    echo "performance" > /sys/class/devfreq/13000000.mali/governor 2>/dev/null

    # Disable thermal
    for tz in /sys/class/thermal/thermal_zone*; do
        echo 0 > $tz/mode 2>/dev/null
    done

    # Touch boost
    echo on > /sys/class/input/event2/device/power/control
    echo -1 > /sys/class/input/event2/device/power/autosuspend_delay_ms
    echo on > /sys/class/input/event4/device/power/control
    echo -1 > /sys/class/input/event4/device/power/autosuspend_delay_ms
    echo 1 > /proc/perfmgr_touch_boost/ioctl_touch_boost 2>/dev/null

    # IO tweaks
    echo "deadline" > /sys/block/mmcblk0/queue/scheduler 2>/dev/null
    echo 0 > /sys/block/mmcblk0/queue/iostats 2>/dev/null

    # RAM tweaks
    echo 200 > /proc/sys/vm/swappiness
    echo 100 > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
    echo 3 > /proc/sys/vm/drop_caches

    # Network tweaks
    sysctl -w net.ipv4.tcp_tw_reuse=1
    sysctl -w net.ipv4.tcp_fin_timeout=15
    sysctl -w net.ipv4.tcp_window_scaling=1
    sysctl -w net.core.rmem_max=16777216
    sysctl -w net.core.wmem_max=16777216

    # Background apps sleep
    cmd app idle com.facebook.katana true 2>/dev/null
    cmd app idle com.instagram.android true 2>/dev/null
}

restore_tweaks() {
    # Restore CPU
    echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null

    # Restore GPU governor
    echo "ondemand" > /sys/class/devfreq/13000000.mali/governor 2>/dev/null

    # Re-enable thermal
    for tz in /sys/class/thermal/thermal_zone*; do
        echo enabled > $tz/mode 2>/dev/null
    done

    # Restore IO
    echo "cfq" > /sys/block/mmcblk0/queue/scheduler 2>/dev/null
}

# Game detection loop
while true; do
    if pidof com.dts.freefireth >/dev/null || pidof com.dts.freefiremax >/dev/null; then
        if [ ! -f /data/local/tmp/.ff_boost_applied ]; then
            apply_tweaks
            sleep 3
            su -lp 2000 -c "cmd notification post -S bigtext -t 'Bad•Monkey' \
            'module' '✅ Bad•Monkey is Online!'"
            touch /data/local/tmp/.ff_boost_applied
        fi
    else
        if [ -f /data/local/tmp/.ff_boost_applied ]; then
            restore_tweaks
            sleep 2
            su -lp 2000 -c "cmd notification post -S bigtext -t 'Bad•Monkey' \
            'module' '♻️ Bad•Monkey is Offline 😴'"
            rm -f /data/local/tmp/.ff_boost_applied
        fi
    fi
    sleep 5
done